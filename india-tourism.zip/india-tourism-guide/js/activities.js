// Category Filtering
const tabButtons = document.querySelectorAll('.tab-btn');
const activityCards = document.querySelectorAll('.activity-card');

tabButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Remove active class from all buttons
        tabButtons.forEach(btn => btn.classList.remove('active'));
        // Add active class to clicked button
        button.classList.add('active');

        const category = button.getAttribute('data-category');

        // Filter activities
        activityCards.forEach(card => {
            if (category === 'all' || card.getAttribute('data-category') === category) {
                card.style.display = 'block';
                // Add animation
                card.style.animation = 'fadeIn 0.5s ease-out';
            } else {
                card.style.display = 'none';
            }
        });
    });
});

// Search Functionality
const searchInput = document.querySelector('.search-bar input');
const searchButton = document.querySelector('.search-bar button');

function performSearch() {
    const searchTerm = searchInput.value.toLowerCase();
    
    activityCards.forEach(card => {
        const title = card.querySelector('h3').textContent.toLowerCase();
        const description = card.querySelector('p').textContent.toLowerCase();
        const location = card.querySelector('.activity-details span:first-child').textContent.toLowerCase();

        if (title.includes(searchTerm) || description.includes(searchTerm) || location.includes(searchTerm)) {
            card.style.display = 'block';
            card.style.animation = 'fadeIn 0.5s ease-out';
        } else {
            card.style.display = 'none';
        }
    });
}

searchButton.addEventListener('click', performSearch);
searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        performSearch();
    }
});

// URL Parameter Handling
window.addEventListener('load', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const searchParam = urlParams.get('search');
    const categoryParam = urlParams.get('category');
    
    if (searchParam) {
        searchInput.value = searchParam;
        performSearch();
    }
    
    if (categoryParam) {
        const categoryButton = document.querySelector(`[data-category="${categoryParam}"]`);
        if (categoryButton) {
            categoryButton.click();
        }
    }
});

// Booking Modal
const bookButtons = document.querySelectorAll('.book-now');
const modal = document.createElement('div');
modal.className = 'booking-modal';
modal.innerHTML = `
    <div class="modal-content">
        <span class="close-modal">&times;</span>
        <h2>Book Activity</h2>
        <form id="booking-form">
            <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" id="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" required>
            </div>
            <div class="form-group">
                <label for="date">Preferred Date</label>
                <input type="date" id="date" required>
            </div>
            <div class="form-group">
                <label for="guests">Number of Guests</label>
                <input type="number" id="guests" min="1" required>
            </div>
            <button type="submit" class="submit-booking">Confirm Booking</button>
        </form>
    </div>
`;

document.body.appendChild(modal);

bookButtons.forEach(button => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        const activityName = button.closest('.activity-card').querySelector('h3').textContent;
        modal.querySelector('h2').textContent = `Book ${activityName}`;
        modal.style.display = 'flex';
    });
});

modal.querySelector('.close-modal').addEventListener('click', () => {
    modal.style.display = 'none';
});

modal.querySelector('#booking-form').addEventListener('submit', (e) => {
    e.preventDefault();
    // Here you would typically send the booking data to your backend
    alert('Booking submitted successfully! We will contact you shortly.');
    modal.style.display = 'none';
});

// Experience Slider
const experienceSlider = document.querySelector('.experience-slider');
let isDown = false;
let startX;
let scrollLeft;

experienceSlider.addEventListener('mousedown', (e) => {
    isDown = true;
    experienceSlider.style.cursor = 'grabbing';
    startX = e.pageX - experienceSlider.offsetLeft;
    scrollLeft = experienceSlider.scrollLeft;
});

experienceSlider.addEventListener('mouseleave', () => {
    isDown = false;
    experienceSlider.style.cursor = 'grab';
});

experienceSlider.addEventListener('mouseup', () => {
    isDown = false;
    experienceSlider.style.cursor = 'grab';
});

experienceSlider.addEventListener('mousemove', (e) => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - experienceSlider.offsetLeft;
    const walk = (x - startX) * 2;
    experienceSlider.scrollLeft = scrollLeft - walk;
});

// Lazy Loading Images
document.addEventListener('DOMContentLoaded', () => {
    const images = document.querySelectorAll('.activity-card img, .experience-card img');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                const src = img.getAttribute('data-src');
                
                if (src) {
                    img.src = src;
                    img.removeAttribute('data-src');
                }
                
                observer.unobserve(img);
            }
        });
    });

    images.forEach(img => imageObserver.observe(img));
}); 