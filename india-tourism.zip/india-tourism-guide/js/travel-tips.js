document.addEventListener('DOMContentLoaded', function() {
    // Initialize collapsible sections
    const tipHeaders = document.querySelectorAll('.tip-header');
    
    tipHeaders.forEach(header => {
        header.addEventListener('click', () => {
            // Toggle active class on header
            header.classList.toggle('active');
            
            // Get the content section
            const content = header.nextElementSibling;
            
            // Toggle content visibility
            if (content.classList.contains('active')) {
                content.classList.remove('active');
                content.style.maxHeight = '0';
            } else {
                content.classList.add('active');
                content.style.maxHeight = content.scrollHeight + 'px';
            }
        });
    });

    // Smooth scroll to section when clicking on quick tip cards
    const tipCards = document.querySelectorAll('.tip-card');
    
    tipCards.forEach(card => {
        card.addEventListener('click', () => {
            const sectionId = card.getAttribute('data-section');
            const section = document.getElementById(sectionId);
            
            if (section) {
                // Open the section if it's closed
                const header = section.querySelector('.tip-header');
                const content = section.querySelector('.tip-content');
                
                if (!content.classList.contains('active')) {
                    header.click();
                }
                
                // Smooth scroll to section
                section.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // Add animation to tip cards when they come into view
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, {
        threshold: 0.1
    });

    tipCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        observer.observe(card);
    });

    // Handle newsletter subscription
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = this.querySelector('input[type="email"]').value;
            
            // Here you would typically send this to your backend
            // For now, we'll just show a success message
            alert('Thank you for subscribing to our newsletter!');
            this.reset();
        });
    }

    // Add search functionality for tips
    const searchInput = document.querySelector('.search-input');
    const searchButton = document.querySelector('.search-button');
    
    if (searchInput && searchButton) {
        const performSearch = () => {
            const searchTerm = searchInput.value.toLowerCase();
            const tipSections = document.querySelectorAll('.tip-section');
            
            tipSections.forEach(section => {
                const content = section.querySelector('.tip-content');
                const text = content.textContent.toLowerCase();
                
                if (text.includes(searchTerm)) {
                    section.style.display = 'block';
                    // Open the section if it contains the search term
                    if (!content.classList.contains('active')) {
                        section.querySelector('.tip-header').click();
                    }
                } else {
                    section.style.display = 'none';
                }
            });
        };
        
        searchButton.addEventListener('click', performSearch);
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
    }

    // Add print functionality
    const printButton = document.querySelector('.print-button');
    if (printButton) {
        printButton.addEventListener('click', () => {
            window.print();
        });
    }

    // Handle URL parameters for direct section access
    const urlParams = new URLSearchParams(window.location.search);
    const sectionParam = urlParams.get('section');
    
    if (sectionParam) {
        const targetSection = document.getElementById(sectionParam);
        if (targetSection) {
            const header = targetSection.querySelector('.tip-header');
            if (header && !header.classList.contains('active')) {
                header.click();
            }
            targetSection.scrollIntoView({ behavior: 'smooth' });
        }
    }
}); 