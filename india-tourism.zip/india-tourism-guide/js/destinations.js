// Filter Functionality
const filterButtons = document.querySelectorAll('.filter-btn');
const destinationCards = document.querySelectorAll('.destination-card');

filterButtons.forEach(button => {
    button.addEventListener('click', () => {
        const category = button.dataset.category;
        
        // Update active state
        filterButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');

        // Filter cards
        destinationCards.forEach(card => {
            if (category === 'all' || card.dataset.category === category) {
                card.style.display = 'block';
                setTimeout(() => card.style.opacity = '1', 50);
            } else {
                card.style.opacity = '0';
                setTimeout(() => card.style.display = 'none', 300);
            }
        });
    });
});

// Search Functionality
const searchInput = document.querySelector('.header-search input');
const searchButton = document.querySelector('.header-search button');

function performSearch() {
    const searchTerm = searchInput.value.toLowerCase();
    
    destinationCards.forEach(card => {
        const title = card.querySelector('h3').textContent.toLowerCase();
        const description = card.querySelector('p').textContent.toLowerCase();
        const location = card.querySelector('.location').textContent.toLowerCase();

        if (title.includes(searchTerm) || 
            description.includes(searchTerm) || 
            location.includes(searchTerm)) {
            card.style.display = 'block';
            setTimeout(() => card.style.opacity = '1', 50);
        } else {
            card.style.opacity = '0';
            setTimeout(() => card.style.display = 'none', 300);
        }
    });
}

searchButton.addEventListener('click', performSearch);
searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        performSearch();
    }
});

// URL Parameter Handling
window.addEventListener('load', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const searchParam = urlParams.get('search');
    const categoryParam = urlParams.get('category');
    
    if (searchParam) {
        searchInput.value = searchParam;
        performSearch();
    }

    if (categoryParam) {
        const categoryButton = document.querySelector(`.filter-btn[data-category="${categoryParam}"]`);
        if (categoryButton) {
            categoryButton.click();
        }
    }
});

// Lazy Loading Images
document.addEventListener('DOMContentLoaded', () => {
    const images = document.querySelectorAll('.destination-card img');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                const src = img.getAttribute('data-src');
                
                if (src) {
                    img.src = src;
                    img.removeAttribute('data-src');
                }
                
                observer.unobserve(img);
            }
        });
    });

    images.forEach(img => imageObserver.observe(img));
});

// Smooth Scroll for "Learn More" Links
document.querySelectorAll('.read-more').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const destinationId = link.getAttribute('href').split('#')[1];
        const destinationElement = document.getElementById(destinationId);
        
        if (destinationElement) {
            destinationElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Save destination functionality
const saveButtons = document.querySelectorAll('.save-btn');
saveButtons.forEach(button => {
    button.addEventListener('click', () => {
        button.classList.toggle('active');
        const isSaved = button.classList.contains('active');
        button.innerHTML = isSaved ? 
            '<i class="fas fa-heart"></i>' : 
            '<i class="far fa-heart"></i>';
        
        // Show notification
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = isSaved ? 
            'Destination saved to favorites!' : 
            'Destination removed from favorites';
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    });
});

// Initialize Swiper
const swiper = new Swiper('.swiper-container', {
    slidesPerView: 1,
    spaceBetween: 30,
    loop: true,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
});

// Initialize Map
const map = L.map('india-map').setView([20.5937, 78.9629], 4); // Center of India

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Add scale control
L.control.scale().addTo(map);

// Region data with more detailed information
const regions = {
    'north': {
        name: 'North India',
        center: [28.7041, 77.1025],
        zoom: 6,
        destinations: [
            { name: 'Taj Mahal', coordinates: [27.1751, 78.0422] },
            { name: 'Golden Temple', coordinates: [31.6200, 74.8765] },
            { name: 'Varanasi', coordinates: [25.3176, 82.9739] }
        ]
    },
    'south': {
        name: 'South India',
        center: [9.9312, 76.2707],
        zoom: 6,
        destinations: [
            { name: 'Kerala Backwaters', coordinates: [9.9312, 76.2707] },
            { name: 'Hampi', coordinates: [15.3350, 76.4600] },
            { name: 'Mysore Palace', coordinates: [12.3051, 76.6554] }
        ]
    },
    'east': {
        name: 'East India',
        center: [20.2961, 85.8245],
        zoom: 6,
        destinations: [
            { name: 'Darjeeling', coordinates: [27.0360, 88.2632] },
            { name: 'Konark Temple', coordinates: [19.8876, 86.0945] },
            { name: 'Sundarbans', coordinates: [21.9497, 88.8727] }
        ]
    },
    'west': {
        name: 'West India',
        center: [19.0760, 72.8777],
        zoom: 6,
        destinations: [
            { name: 'Goa', coordinates: [15.4989, 73.8567] },
            { name: 'Ajanta Caves', coordinates: [20.5519, 75.7000] },
            { name: 'Rann of Kutch', coordinates: [23.7337, 69.8597] }
        ]
    },
    'central': {
        name: 'Central India',
        center: [23.5937, 78.9629],
        zoom: 6,
        destinations: [
            { name: 'Khajuraho', coordinates: [24.8500, 79.9333] },
            { name: 'Sanchi Stupa', coordinates: [23.4809, 77.7397] },
            { name: 'Kanha National Park', coordinates: [22.3000, 80.6000] }
        ]
    }
    
};

// Custom marker icon
const customIcon = L.icon({
    iconUrl: 'images/marker.png',
    iconSize: [30, 30],
    iconAnchor: [15, 30],
    popupAnchor: [0, -30]
});

// Add markers for destinations
function addDestinationMarkers(region) {
    // Remove existing markers
    map.eachLayer((layer) => {
        if (layer instanceof L.Marker) {
            map.removeLayer(layer);
        }
    });

    // Add new markers
    regions[region].destinations.forEach(dest => {
        const marker = L.marker(dest.coordinates, { icon: customIcon })
            .addTo(map)
            .bindPopup(`<h3>${dest.name}</h3>`);
    });
}

// Handle region selection
const regionList = document.querySelector('.region-list');
regionList.addEventListener('click', function(e) {
    if (e.target.tagName === 'LI') {
        const region = e.target.dataset.region;
        const regionData = regions[region];
        
        // Update map view
        map.setView(regionData.center, regionData.zoom, {
            animate: true,
            duration: 1
        });

        // Update active state
        document.querySelectorAll('.region-list li').forEach(li => {
            li.classList.remove('active');
        });
        e.target.classList.add('active');

        // Update region info
        document.querySelector('.map-info h3').textContent = regionData.name;
        const destinationsList = document.querySelector('.region-destinations ul');
        destinationsList.innerHTML = regionData.destinations
            .map(dest => `<li>${dest.name}</li>`)
            .join('');

        // Add markers for the selected region
        addDestinationMarkers(region);
    }
});

// Initialize map with North India markers
document.addEventListener('DOMContentLoaded', () => {
    addDestinationMarkers('north');
    document.querySelector('.region-list li[data-region="north"]').click();
}); 
